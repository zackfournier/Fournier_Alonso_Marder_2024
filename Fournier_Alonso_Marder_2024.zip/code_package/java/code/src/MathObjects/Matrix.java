package MathObjects;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Matrix {
	double[][] matrix;
	
	
	public Matrix(List<RealVector> x){
		this.matrix = new double[x.size()][x.get(0).getDimension()];
		for (int i = 0; i < x.size(); i++) {
			this.setRow(i, x.get(i));
		}
	}
	
	public Matrix(int rows, int cols){
		this.matrix = new double[rows][cols];
		fillWithZeros();
	}
	
	public void fillWithZeros(){
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				this.matrix[i][j]=0;
			}
		}
	}
	
	public void fillWith(double num){
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				this.matrix[i][j]=num;
			}
		}
	}
	
	public void setRow(int i, RealVector row){
		for(int j = 0; j<row.getDimension() ; j++){
			this.matrix[i][j] = row.get(j);
		}
	}
	
	public void set(int i, int j, double x){
		this.matrix[i][j] = x;
	}
	
	public double get(int i, int j){
		return this.matrix[i][j];
	}
	
	public void setCol(int j, RealVector col){
		for(int i = 0; i<col.getDimension() ; i++){
			this.matrix[i][j] = col.get(i);
		}
	}
	
	public RealVector getRow(int i){
		RealVector row = new RealVector(matrix[i].length);
		for (int j = 0; j < matrix[i].length; j++) {
			row.set(j, matrix[i][j]);
//			System.out.println(matrix[i][j]);
		}
		return row;
	}
	
	public RealVector getCol(int i){
		RealVector col = new RealVector(matrix.length   );
		for (int j = 0; j < matrix.length; j++) {
			col.set(j, matrix[j][i]);
		}
		return col;
	}
	
	public int getRowNumber(){
		return matrix.length;
	}
	public int getColNumber(){
		return matrix[0].length;
	}
	
	public List<RealVector> toListOfRealVector(){
		List<RealVector> r = new ArrayList<RealVector>();
		for (int i = 0; i < matrix.length; i++) {
			r.add(this.getRow(i));
		}
		return r;
	}
	
	public Matrix removeCol(int j){
		
		Matrix r = new Matrix(this.rows(), this.cols()-1);
		for(int i = 0 ; i<j ; i++){
				r.setCol(i, this.getCol(i));
		}
		for(int i = j ; i<r.cols() ; i++){
			r.setCol(i, this.getCol(i+1));
		}
		
		return r;		
	}
	
	public void writeToFile(String filename) throws IOException{
		FileWriter fw = new FileWriter(filename);
		fw.write(this.toString());
		fw.close();
	}
	
	public int rows(){
		return matrix.length;
	}
	
	public int cols(){
		return matrix[0].length;
	}
	
	public String toString(){
		String r = "";
		for (int i = 0; i < matrix.length; i++) {
			r = r + this.getRow(i).toStringBis() + "\n";
		}
		return r;
	}
	public double getDeterminant(){
		return determinant(this.matrix);
	}

	public double determinant(double[][] mat) { 
		double result = 0; 
		
		if(mat.length == 1) { 
			result = mat[0][0]; 
			return result; 
		} 
		
		if(mat.length == 2) { 
			result = mat[0][0] * mat[1][1] - mat[0][1] * mat[1][0]; 
			return result; 
		} 
		
		for(int i = 0; i < mat[0].length; i++) { 
			double temp[][] = new double[mat.length - 1][mat[0].length - 1]; 
			
			for(int j = 1; j < mat.length; j++) { 
				for(int k = 0; k < mat[0].length; k++) { 
					
					if(k < i) { 
						temp[j - 1][k] = mat[j][k]; 
					} else if(k > i) { 
						temp[j - 1][k - 1] = mat[j][k]; 
					} 
					
				} 
			} 
			
			result += mat[0][i] * Math.pow(-1, (double)i) * determinant(temp); 
		} 
		
		return result; 
	}
	public static void main(String[] args) {
		RealVector a = new RealVector(5);
		RealVector b = new RealVector(3);
		b.set(0, 1);
		b.set(1, -1);
		b.set(2, 2);
		
		a.set(0, 7);
		a.set(1, 11);
		a.set(2, 13);
		a.set(3, 17);
		a.set(4, 19);
//		System.out.println("prueba");
		
//		Matrix x = new Matrix(5, 3);
//		System.out.println(x.toString());
		
		Matrix x = new Matrix(2,2);
		
		x.set(0, 0, 1);
		x.set(0, 1, 2);
		
		x.set(1, 0, 1);
		x.set(1, 1, 3);
		System.out.println("Matriz: \n");
		System.out.println(x);
		System.out.println("Determinante: \n");
		System.out.println(x.getDeterminant());
		
	}

	public Matrix getTranspose() {
		// TODO Auto-generated method stub
		Matrix xt = new Matrix(this.getRowNumber(), getColNumber());
		for (int i = 0; i < this.getRowNumber(); i++) {
			for (int j = 0; j < this.getColNumber(); j++) {
				xt.set(i, j, this.get(j, i)); 				
			}
		}
		return xt;
	}
}

