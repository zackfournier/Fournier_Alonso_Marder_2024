package MathObjects;
import java.util.ArrayList;
import java.util.List;

import MathObjects.Grid;
import MathObjects.Matrix;
import MathObjects.RealVector;
import MathObjects.SimpleDomain;



public class MathUtil {
	
	
	public static int factorial(int n) {
        int fact = 1; // this  will be the result
        for (int i = 1; i <= n; i++) {
            fact *= i;
        }
        return fact;
    }
	
	public static Matrix getOuterProduct(RealVector x,RealVector y){
		Matrix r = new Matrix(x.getDimension(), y.getDimension());
		for (int i = 0; i < x.getDimension(); i++) {
			for (int j = 0; j < y.getDimension(); j++) {
				r.set(i, j, x.get(i)*y.get(j));
			}			
		}
		return r;
	}
	
	
	public static double Distance(RealVector x, RealVector y) {
		if (x.getDimension() != y.getDimension()) {
			System.out.println("Un vector es mas largo que el otro!");
			return 0;
		}
		double e = 0;
		for (int i = 0; i < x.getDimension(); i++) {
			double d = (x.get(i) - y.get(i));
			e = e + (d * d);
		}
		e = Math.sqrt((1. / x.getDimension()) * e);
		return e;
	}
	
	
	public static double  cost(RealVector x, RealVector y){
		if (x.getDimension() != y.getDimension()) {
			System.out.println("Un vector es mas largo que el otro!");
			return 0;
		}
		double e = 0;
		for (int i = 0; i < x.getDimension(); i++) {
			double d = (x.get(i) - y.get(i));
			e = e + (d * d);
		}
//		e = Math.sqrt( e);
		return e/(y.getDimension());
	}
	
	
	public static double distanceNorm1(RealVector x, RealVector y){
		if (x.getDimension() != y.getDimension()) {
			System.out.println("Un vector es mas largo que el otro!");
			return 0;
		}
		double e = 0;
		for (int i = 0; i < x.getDimension(); i++) {
			double d = (x.get(i) - y.get(i));
			double absd = Math.sqrt( d*d);
			if(absd>e){
				e=absd;
			}
		}
//		e = Math.sqrt( e);
		return e;
	}
	
	public static double distance(RealVector x, RealVector y) {
		if (x.getDimension() != y.getDimension()) {
			System.out.println("Un vector es mas largo que el otro!");
			return 0;
		}
		double e = 0;
		for (int i = 0; i < x.getDimension(); i++) {
			double d = (x.get(i) - y.get(i));
			e = e + (d * d);
		}
		e = Math.sqrt( e);
		return e;
	}

	public static double DistanceWithTransient(RealVector x, RealVector y,
			int transiente) {
		int t = transiente;
		if (((x.getDimension() != y.getDimension()) || t >= x.getDimension())) {
			System.out.println("Un vector es mas largo que el otro!");
			return 0;
		}
		double e = 0;
		for (int i = t; i < x.getDimension(); i++) {
			double d = (x.get(i) - y.get(i));
			e = e + d * d;
		}
		e = Math.sqrt((1. / x.getDimension()) * e);
		return e;
	}
	
	public static boolean isInDomain(RealVector x,SimpleDomain space) {
		for (int i = 0; i < x.getDimension(); i++) {
			if (x.get(i) < space.getBounds(i)[0]
					|| x.get(i) > space.getBounds(i)[1]) {
				return false;
			}
		}
		return true;
	}
	
	public static RealVector getCenterOfDomain(SimpleDomain domain){
		RealVector center = new RealVector(domain.getDimension());
		for (int i = 0; i < center.getDimension(); i++) {
			center.set(i, (domain.getBounds(i)[1]-domain.getBounds(i)[0])/2  + domain.getBounds(i)[0]); 
		}
		return center;
	}
	
	public static RealVector getEpsCenterOfDomain(SimpleDomain domain){
		RealVector eps = new RealVector(domain.getDimension());
		for (int i = 0; i < eps.getDimension(); i++) {
			eps.set(i, (domain.getBounds(i)[1]-domain.getBounds(i)[0])/2); 
		}
		return eps;
	}
	
	public static List<RealVector> getRealVectorsInGridDomain(SimpleDomain sd, Grid grid){
		List<RealVector> r = new ArrayList<RealVector>();
		while (grid.next()) {
			System.out.println(grid.getStateVector().toStringBis());
			System.out.println();
			r.add(sd.getScaledToDomain((grid.getStateVector())));
		}
		return r;
	}
	public static void main(String[] args) {
		SimpleDomain sd = new SimpleDomain();
		sd.addDimension(0, 50);
		sd.addDimension(0, 50);
		Grid grid = new Grid();
		grid.addDimension(20);
		grid.addDimension(20);
		Matrix x = new Matrix(getRealVectorsInGridDomain(sd, grid));
		System.out.println(x);
	}
	
}
