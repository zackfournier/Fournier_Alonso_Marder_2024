package MathObjects;


import java.util.ArrayList;
import java.util.List;

import MathObjects.RealVector;

public class Grid {
	
	public List<Integer> bounds;
	public List<Integer> state;
	
//	Este es el constructor
	public Grid() {
		bounds = new ArrayList<Integer>();
		state = new ArrayList<Integer>();
	}
	
	public Grid(RealVector x){
		bounds = new ArrayList<Integer>();
		state = new ArrayList<Integer>();
		
		for (int i = 0; i < x.getDimension(); i++) {
			addDimension((int)x.get(i));
		}
		
	}
	
	public Grid(int x ,int y){
		bounds = new ArrayList<Integer>();
		state = new ArrayList<Integer>();
		bounds.add(x);
		bounds.add(y);
	}
	/**
	 * Adds a new dimension to the grid, with n=bounds elements
	 * @param bound Sets how many elements has this dimension
	 */
	public void addDimension(int bound) {
		bounds.add(bound);
		state.add(0);
		
	}

	
	
	
	/**
	 * Moves to the next element of the grid. If there is no next element, it returns false
	 * @return boolean
	 */
	
	public boolean next() {
		int n = bounds.size();
		for (int i = 0; i < n; i++) {
			int s = state.get(i);
			if (s < bounds.get(i) - 1) {
				state.set(i, s + 1);
				return true;
			} else {
				state.set(i, 0);
			}
		}
		return false;
	}

	

	/**
	 * Returns the state of the grid (the point where I am standing) scaled between [0,1)
	 * For example, if the grid is 45x60x50, and the state of the grid is (5,15,21) the method
	 * returns a list of doubles (5/45 , 15/60 , 21/50)
	 */
	
	 public List<Double> getState() {
		List<Double> result = new ArrayList<Double>(); // aca esta declarando
		// una variable interna
		// del tipo lista
		// doubles
		for (int i = 0; i < state.size(); i++) {
			int s = state.get(i);
			double x = ((double) s) / ((double) bounds.get(i));
			result.add(x);
		}
		return result;
	}
	 
	public RealVector getStateVector(){
		RealVector r = new RealVector(state.size());
		for(int i = 0 ; i < r.getDimension() ; i ++){
			r.set(i, state.get(i));
		}
		return r;
	}
	 
	 public void setState(RealVector s){
		 for(int i=0; i<state.size(); i++){
			 state.set(i, (int)s.get(i));
		 }
	 }
	 
	 public void moveToRandomState(){
		for(int i = 0; i < state.size(); i++){
			
			int aux =bounds.get(i); 			
			
				int newvalue = (int) Math.floor(Math.random()*(aux)   + 1);
				
				state.set(i, newvalue);
			
			
		}
	 }
	 
	 public void moveToRandomNeighboor(){
		 boolean done = false;
		 
		 do{
//			System.out.println("entre al while");
			int coord = (int) Math.floor(Math.random()*(state.size()));
//			System.out.println("muevo la corrdenada " + coord);
			int a = 1;
			if(Math.random()<0.5){
				a=1;
			}
			else{
				a=-1;
			}
			int newvalue = state.get(coord) + a ;
			if( ( newvalue <= bounds.get(coord) && newvalue>0)){
//				System.out.println("entre al if");
				state.set(coord, newvalue);
				done = true;
			}
		 }while(done == false);		 
	 }
	 
	 /**
	  * Returns the state of the grid, ie: in which point I am standing. Is the same as method getState
	  * but non scaled.
	  * @return int[]
	  */
	 
	 public int[] getStateInt() {
			int[] result = new int[bounds.size()]; 			
			for (int i = 0; i < state.size(); i++) {
				result[i] = state.get(i);
			}
			return result;
		}
	 
	 
//	Este es el toString de la clase Grid
	public String toString() {
		return "{Grid: " + bounds + ", " + state + "}";
	}

	public static void main(String[] args) {
		Grid grilla = new Grid();
		grilla.addDimension(1);
		grilla.addDimension(1);
		grilla.addDimension(5);
		grilla.addDimension(17);
		grilla.addDimension(9);
		
		grilla.state.set(0, 1);
		grilla.state.set(1, 1);
		grilla.state.set(2, 2);
		grilla.state.set(3, 12);
		grilla.state.set(4, 6);
		
		
		for(int i= 0; i<100;i++){
			System.out.println(grilla.state.toString());
			grilla.moveToRandomState();
		}
	}

}