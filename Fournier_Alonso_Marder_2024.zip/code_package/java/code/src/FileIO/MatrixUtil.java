package FileIO;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import MathObjects.Matrix;
import MathObjects.RealVector;

public class MatrixUtil {

	public List<RealVector> getListOfRealVectorFromFile(String file) {
		List<RealVector> pop = new ArrayList<RealVector>();
		float[][] matrix = ReadMatrixFromFile.read(ReadMatrixFromFile
				.getBufferedReader(file));
		for (int i = 0; i < matrix.length; i++) {
			RealVector individual = new RealVector(matrix[i].length);
			for (int j = 0; j < matrix[i].length; j++) {
				individual.set(j, matrix[i][j]);
			}
			pop.add(individual);
		}
		return pop;
	}

	public List<RealVector> extractColumnsFromFile(String file, int[] columns) {
		List<RealVector> all = getListOfRealVectorFromFile(file);
		List<RealVector> selection = new ArrayList<RealVector>();
		for (int i = 0; i < all.size(); i++) {
			RealVector small = new RealVector(columns.length);
			RealVector big = all.get(i);
			for (int j = 0; j < columns.length; j++) {
				small.set(j, big.get(columns[j]));
			}
			selection.add(small);
		}
		return selection;
	}

	public static Matrix fileToMatrix(String file) {
		List<RealVector> pop = new ArrayList<RealVector>();
		float[][] matrix = ReadMatrixFromFile.read(ReadMatrixFromFile
				.getBufferedReader(file));
		for (int i = 0; i < matrix.length; i++) {
			RealVector individual = new RealVector(matrix[i].length);
			for (int j = 0; j < matrix[i].length; j++) {
				individual.set(j, matrix[i][j]);
			}
			pop.add(individual);
		}
		Matrix x = new Matrix(pop);
		return x;
	}

	public static void matrixToFile(String file, List<RealVector> matrix)
			throws IOException {
		FileWriter fw = new FileWriter(file);
		for (int i = 0; i < matrix.size(); i++) {
			fw.write(matrix.get(i).toStringBis() + "\n");
		}
		fw.close();
	}

}
