package FileIO;



import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class ReadMatrixFromFile {
	   /**
	    * Given a file name, return a BufferedReader object for that file
	    * or null if the file could not be found or there is some other
	    * error.
	    */
	   @SuppressWarnings("hiding")
	public static BufferedReader getBufferedReader(String fileName) {
	       BufferedReader bufReader = null;
	       try {
	           FileReader reader = new FileReader(fileName);
	           bufReader = new BufferedReader(reader);
	       }
	       catch (FileNotFoundException e1) {
	           System.out.println("File " + fileName + " not found");
	       }
	       catch (IOException e2) {
	           System.out.println("Error: " + e2 );
	       }

	       return bufReader;
	   }

	   /**
	    * Given a list of strings, build a matrix.
	    *
	    * Each string in the list should be a comma separated set of
	    * floating point numbers.  There should be the same number
	    * of floating point numbers in each set.
	    */
	   @SuppressWarnings("unchecked")
	private static float[][] stringListToMatrix(ArrayList list) {
	       float[][] matrix = null;
	       int len = list.size();
	       if (len > 0) {
	           String curNumber = null;
	           matrix = new float[len][];

	           try {
	               for (int i = 0; i < len; i++) {
	                   String line = (String)list.get(i);
	                   String[] floatStrVec = line.split(" ");
	                   int rowLen = floatStrVec.length;
	                   matrix[i] = new float[rowLen];
	                   for (int j = 0; j < rowLen; j++) {
	                       curNumber = floatStrVec[j];
	                       float val = Float.parseFloat(curNumber);
	                       matrix[i][j] = val;
	                   } // for j
	               } // for i
	           } // try
	           catch (NumberFormatException e) {
	               System.out.println("Could not convert \"" + curNumber + "\" to floating point");
	           }
	       }

	       return matrix;
	   }

	   /**
	    * Read a matrix from a file. The elements of a matrix are separated
	    * by commas and matrices are separated by at least one blank line.
	    * This function is using 32-bit floating point.
	    */
	   @SuppressWarnings("unchecked")
	public static float[][] read(BufferedReader reader) {
	       float[][] matrix = null;

	       try {
	           // Read any blank lines before the matrix
	           String line = null;
	           do {
	               line = reader.readLine();
	           } while (line != null && line.trim().equals(""));

	           ArrayList list = new ArrayList();

	           while (line != null && (!line.trim().equals(""))) {
	               list.add(line);
	               line = reader.readLine();
	           }

	           matrix = stringListToMatrix(list);
	       }
	       catch (IOException e) {
	           System.out.println("readMatrix I/O error: " + e);
	       }
	       return matrix;
	   }
	   
	   public static float[]readColumn(BufferedReader reader, int colnumb) {
	       float[] out = null;

	       try {
	           // Read any blank lines before the matrix
	           String line = null;
	           do {
	               line = reader.readLine();
	           } while (line != null && line.trim().equals(""));

	           ArrayList<String> list = new ArrayList<String>();

	           while (line != null && (!line.trim().equals(""))) {
	               list.add(line);
	               line = reader.readLine();
	           }

	           //out = stringListToMatrix(list);
	       }
	       catch (IOException e) {
	           System.out.println("readMatrix I/O error: " + e);
	       }
	       return out;
	   }
}

