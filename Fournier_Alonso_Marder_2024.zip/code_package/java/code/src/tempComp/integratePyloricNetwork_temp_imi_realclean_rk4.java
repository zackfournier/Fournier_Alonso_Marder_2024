package tempComp;
import java.io.IOException;

import conductanceBasedModels.PrinzNetworkWithTemperature_full_eu_slow_same_q10s_rk4;
import conductanceBasedModels.pyloricNetworkPrinz_q10_imi_realclean_rk4;
import conductanceBasedModels.pyloricNetworkPrinz_q10_imi_rk4;
import FileIO.FileUtil;
import MathObjects.Integrador;
import MathObjects.RealVector;

public class integratePyloricNetwork_temp_imi_realclean_rk4 {
	public static void main(String[] args) throws IOException {
		RealVector cis = FileUtil.FileToVector(args[0]);
		RealVector parameters = FileUtil.FileToVector(args[1]);
		double nsecs = Double.parseDouble(args[2]);
		double temp = Double.parseDouble(args[3]);		
		double dt = Double.parseDouble(args[4]);
//		double dt=0.1;
		pyloricNetworkPrinz_q10_imi_realclean_rk4 model = new pyloricNetworkPrinz_q10_imi_realclean_rk4();
		model.setParameters(parameters);
		model.setTemperature(temp);	
		double nsteps = (1000*nsecs)/dt;
		RealVector s = cis.copy();
//		System.out.println(nsteps);
		Integrador rk = new Integrador(dt);
		for(int i = 0; i<nsteps; i++){
//			System.out.println(s.toStringBis());
			System.out.println(s.get(0) + " " +s.get(14)+ " " +s.get(14*2) );
			s= rk.rk4(model, s);
//			s= model.evaluate(s);			
		}		
	}
}
