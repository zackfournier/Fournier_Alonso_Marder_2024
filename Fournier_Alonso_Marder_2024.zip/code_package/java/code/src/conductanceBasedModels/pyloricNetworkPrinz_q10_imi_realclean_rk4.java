package conductanceBasedModels;
import MathObjects.RealVector;
import MathObjects.RealVectorField;
import MathObjects.singleCompTemperature_slow_explicit;

public class pyloricNetworkPrinz_q10_imi_realclean_rk4 extends RealVectorField {
	public RealVector p;
	public int dim = (14*3) + 7;
	public double temp;
	public double reftemp;
	singleCompTemperature_imi_realclean cell1;
	singleCompTemperature_imi_realclean cell2;
	singleCompTemperature_imi_realclean cell3;
	int celldim ;
	
	double Eglut;
	double Echol;
	double kglut;
	double kchol;
	double Vthresh;
	double DSyn; 
	int pdim;
	
	public pyloricNetworkPrinz_q10_imi_realclean_rk4(){//, RealVector p, double ggap){
		super("prinzNetwork");	
//		this.pdim =(38*3)+7+14;
		this.pdim=40;
//		this.p = p;
		this.dim= (14*3) + 7;
		this.celldim = 14;
		this.reftemp= 25;
		
		this.cell1 = new singleCompTemperature_imi_realclean();
		this.cell2 = new singleCompTemperature_imi_realclean();
		this.cell3 = new singleCompTemperature_imi_realclean();
//		SET temp
		this.temp=10;
		
		
		cell1.setRefTemp(reftemp);
		cell2.setRefTemp(reftemp);
		cell3.setRefTemp(reftemp);
		
		cell1.setTemperature(temp);
		cell2.setTemperature(temp);	
		cell3.setTemperature(temp);
		this.Eglut = -70.0;
		// # Cholinergic reversal potential
		this.Echol = -80.0;
		// # K for glutamateric synapses
		this.kglut = 1./40.;
		// # K for cholinergic synapses
		this.kchol = 1./100.;
		// # Threshold for all synapse types
		this.Vthresh = -35.0;
		// # Delta for all synapse types
		this.DSyn = 5.00;
	}	
	
	public void setRefTemp(double newreftemp){
		this.reftemp = newreftemp;
		this.cell1.setRefTemp(newreftemp);
		this.cell2.setRefTemp(newreftemp);
		this.cell3.setRefTemp(newreftemp);
	}
	
	public RealVector evaluate(RealVector v) {		
		
		RealVector scell1 = v.getPart(0, celldim);		
		RealVector scell2 = v.getPart(celldim, celldim*2);
		RealVector scell3 = v.getPart(celldim*2, celldim*3);
		
		RealVector syn = v.getPart(celldim*3, (celldim*3) + 7);
		
//		get membrane potentials		
		double VABPD = scell1.get(0);
	    double VLP = scell2.get(0);
	    double VPY = scell3.get(0);
	    
	    double ABPYglut=syn.get(0);
	    double ABPYchol=syn.get(1);
	    double ABLPglut=syn.get(2);
	    double ABLPchol=syn.get(3);
	    double LPPYglut=syn.get(4);
	    double PYLPglut=syn.get(5);
	    double LPABglut=syn.get(6);
	    
	    RealVector g_syn = p.getPart(3*pdim, 3*pdim + (7));
//	    System.out.println(g_syn.toStringBis());
//	    double iABPYglut = iSyn(g_abpy_g, ABPYglut, VPY, Eglut);
//	    double iABPYchol = iSyn(g_abpy_c, ABPYchol, VPY,  Echol);
//	    double iABLPglut = iSyn(g_ablp_g, ABLPglut, VLP, Eglut);
//	    double iABLPchol = iSyn(g_ablp_c, ABLPchol, VLP, Echol);
//	    double iLPPYglut = iSyn(g_lppy_g, LPPYglut, VPY,   Eglut);
//	    double iPYLPglut = iSyn(g_pylp_g, PYLPglut, VLP, Eglut);
//	    double iLPABglut = iSyn(g_lpab_g, LPABglut, VABPD, Eglut);
//	    Get currents
	    
	    RealVector syn_q10 = p.getPart(3*pdim + (7), 3*pdim + (7)+(7*2));
	    
//	    tauHM	 = tauHM  * ;
	    
////	    OJO ACA! CONDUCTANCES SHOULD INCREASE WITH TEMPERATURE. 
//	    double iABPYglut = iSyn(Math.pow(syn_q10.get(0),(temp-reftemp)/10.) * g_syn.get(0), ABPYglut, VPY, Eglut);
//	    double iABPYchol = iSyn(Math.pow(syn_q10.get(1),(temp-reftemp)/10.) * g_syn.get(1), ABPYchol, VPY,  Echol);
//	    double iABLPglut = iSyn(Math.pow(syn_q10.get(2),(temp-reftemp)/10.) * g_syn.get(2), ABLPglut, VLP, Eglut);
//	    double iABLPchol = iSyn(Math.pow(syn_q10.get(3),(temp-reftemp)/10.) * g_syn.get(3), ABLPchol, VLP, Echol);
//	    double iLPPYglut = iSyn(Math.pow(syn_q10.get(4),(temp-reftemp)/10.) * g_syn.get(4), LPPYglut, VPY,   Eglut);
//	    double iPYLPglut = iSyn(Math.pow(syn_q10.get(5),(temp-reftemp)/10.) * g_syn.get(5), PYLPglut, VLP, Eglut);
//	    double iLPABglut = iSyn(Math.pow(syn_q10.get(6),(temp-reftemp)/10.) * g_syn.get(6), LPABglut, VABPD, Eglut);

//	    OJO ACA! CONDUCTANCES SHOULD INCREASE WITH TEMPERATURE. 
	    double iABPYglut = iSyn(Math.pow(syn_q10.get(0),(temp-reftemp)/10.) * g_syn.get(0), ABPYglut, VPY, Eglut);
	    double iABPYchol = iSyn(Math.pow(syn_q10.get(1),(temp-reftemp)/10.) * g_syn.get(1), ABPYchol, VPY,  Echol);
	    double iABLPglut = iSyn(Math.pow(syn_q10.get(0),(temp-reftemp)/10.) * g_syn.get(2), ABLPglut, VLP, Eglut);
	    double iABLPchol = iSyn(Math.pow(syn_q10.get(1),(temp-reftemp)/10.) * g_syn.get(3), ABLPchol, VLP, Echol);
	    double iLPPYglut = iSyn(Math.pow(syn_q10.get(0),(temp-reftemp)/10.) * g_syn.get(4), LPPYglut, VPY,   Eglut);
	    double iPYLPglut = iSyn(Math.pow(syn_q10.get(0),(temp-reftemp)/10.) * g_syn.get(5), PYLPglut, VLP, Eglut);
	    double iLPABglut = iSyn(Math.pow(syn_q10.get(0),(temp-reftemp)/10.) * g_syn.get(6), LPABglut, VABPD, Eglut);
//	    System.out.println(iABPYglut);
//	    System.out.println(iABPYchol);
//	    System.out.println(iABLPglut);
//	    System.out.println(iABLPchol);
//	    System.out.println(iLPPYglut);	    
//	    System.out.println(iPYLPglut);
//	    System.out.println(iLPABglut);
// 		SET Currents		
		int np =pdim;
		RealVector p1 = p.getPart(0, pdim);
		RealVector p2 = p.getPart(pdim, 2*pdim);
		RealVector p3 = p.getPart(2*pdim, 3*pdim);
		
//		SAME Q10 SETS FOR ALL CELLS. ONLY MOVING CELL 1 Q10NS AND PASSING COPIES, 
		RealVector q10s = p1.getPart(13, 38);
		for(int i=13; i<38 ; i++){
			p2.set(i, q10s.get(i-13));
			p3.set(i, q10s.get(i-13));
		}
			
//		RealVector g_syn = p.getPart(3*37, 3*37 + (7));		
		double injcurr1 = p1.get(pdim-1);
		double injcurr2 = p2.get(pdim-1);
		double injcurr3 = p3.get(pdim-1);
		
		double currintoAB = injcurr1  + iLPABglut; 
		double currintoLP = injcurr2  + iABLPglut+iABLPchol+iPYLPglut;
		double currintoPY = injcurr3  + iABPYglut+iABPYchol+iLPPYglut;
		
		p1.set(np-1,-currintoAB);
		p2.set(np-1,-currintoLP);
		p3.set(np-1,-currintoPY);
		cell1.setParameters(p1);
		cell2.setParameters(p2);
		cell3.setParameters(p3);
	    
//	    EVOLVE SYNAPSES
// 		# Synaptic Equations
// 		# Synaptic Steady States
	    double ABPYglutSS = synSS(Vthresh, VABPD, DSyn);
	    double ABPYcholSS = synSS(Vthresh, VABPD, DSyn);
	    double ABLPglutSS = synSS(Vthresh, VABPD, DSyn);
	    double ABLPcholSS = synSS(Vthresh, VABPD, DSyn);
	    double LPPYglutSS = synSS(Vthresh, VLP, DSyn);
	    double PYLPglutSS = synSS(Vthresh, VPY, DSyn);
	    double LPABglutSS = synSS(Vthresh, VLP, DSyn);
// 		# Synaptic Time Constants
//	    double tauABPYglut = Math.pow(syn_q10.get(7),-(temp-reftemp)/10.) *  tauSyn(ABPYglutSS, kglut);
//	    double tauABPYchol = Math.pow(syn_q10.get(8),-(temp-reftemp)/10.) *  tauSyn(ABPYcholSS, kchol);
//	    double tauABLPglut = Math.pow(syn_q10.get(9),-(temp-reftemp)/10.) * tauSyn(ABLPglutSS, kglut);
//	    double tauABLPchol = Math.pow(syn_q10.get(10),-(temp-reftemp)/10.) * tauSyn(ABLPcholSS, kchol);
//	    double tauLPPYglut = Math.pow(syn_q10.get(11),-(temp-reftemp)/10.) * tauSyn(LPPYglutSS, kglut);
//	    double tauPYLPglut = Math.pow(syn_q10.get(12),-(temp-reftemp)/10.) * tauSyn(PYLPglutSS, kglut);
//	    double tauLPABglut = Math.pow(syn_q10.get(13),-(temp-reftemp)/10.) * tauSyn(LPABglutSS, kglut);
	    
	    double tauABPYglut = Math.pow(syn_q10.get(7),-(temp-reftemp)/10.) *  tauSyn(ABPYglutSS, kglut);
	    double tauABPYchol = Math.pow(syn_q10.get(8),-(temp-reftemp)/10.) *  tauSyn(ABPYcholSS, kchol);
	    double tauABLPglut = Math.pow(syn_q10.get(7),-(temp-reftemp)/10.) *  tauSyn(ABLPglutSS, kglut);
	    double tauABLPchol = Math.pow(syn_q10.get(8),-(temp-reftemp)/10.) *  tauSyn(ABLPcholSS, kchol);
	    double tauLPPYglut = Math.pow(syn_q10.get(7),-(temp-reftemp)/10.) *  tauSyn(LPPYglutSS, kglut);
	    double tauPYLPglut = Math.pow(syn_q10.get(7),-(temp-reftemp)/10.) *  tauSyn(PYLPglutSS, kglut);
	    double tauLPABglut = Math.pow(syn_q10.get(7),-(temp-reftemp)/10.) *  tauSyn(LPABglutSS, kglut);
	    
	    
//	    System.out.println("synapses states " + syn.toStringBis());
	    
//	    System.out.println(ABPYglutSS + "  " +ABPYglut  +  "  " + tauABPYglut);
//	    System.out.println(ABPYcholSS);
//	    System.out.println(ABLPglutSS);
//	    System.out.println(ABLPcholSS);
//	    System.out.println(LPPYglutSS);	    
//	    System.out.println(PYLPglutSS);
//	    System.out.println(LPABglutSS);
//	    
	    
//	    System.out.println(tauABPYglut);
//	    System.out.println(tauABPYchol);
//	    System.out.println(tauABLPglut);
//	    System.out.println(tauABLPchol);
//	    System.out.println(tauLPPYglut);	    
//	    System.out.println(tauPYLPglut);
//	    System.out.println(tauLPABglut);

	    
	    double bound =1;
	    double dABPYglut = (ABPYglutSS - ABPYglut)/(tauABPYglut+bound);
	    double dABPYchol = (ABPYcholSS - ABPYchol)/(tauABPYchol+bound);
	    double dABLPglut = (ABLPglutSS - ABLPglut)/(tauABLPglut+bound);
	    double dABLPchol = (ABLPcholSS - ABLPchol)/(tauABLPchol+bound);
	    double dLPPYglut = (LPPYglutSS - LPPYglut)/(tauLPPYglut+bound);
	    double dPYLPglut = (PYLPglutSS - PYLPglut)/(tauPYLPglut+bound);
	    double dLPABglut = (LPABglutSS - LPABglut)/(tauLPABglut+bound);
	    
//	    AHinf + (-AHinf + AH) * Math.exp(-dt / tauAH);
//	    double ABPYglut_n = ABPYglutSS + (-ABPYglutSS + ABPYglut) *Math.exp(-dt / tauABPYglut);
//	    double ABPYchol_n = ABPYcholSS + (-ABPYcholSS + ABPYchol) *Math.exp(-dt / tauABPYchol);
//	    double ABLPglut_n = ABLPglutSS + (-ABLPglutSS + ABLPglut) *Math.exp(-dt / tauABLPglut);
//	    double ABLPchol_n = ABLPcholSS + (-ABLPcholSS + ABLPchol) *Math.exp(-dt / tauABLPchol);
//	    double LPPYglut_n = LPPYglutSS + (-LPPYglutSS + LPPYglut) *Math.exp(-dt / tauLPPYglut);
//	    double PYLPglut_n = PYLPglutSS + (-PYLPglutSS + PYLPglut) *Math.exp(-dt / tauPYLPglut);
//	    double LPABglut_n = LPABglutSS + (-LPABglutSS + LPABglut) *Math.exp(-dt / tauLPABglut);
	    RealVector synapses_dot=new RealVector(7);
	    synapses_dot.set(0,dABPYglut);
	    synapses_dot.set(1,dABPYchol);
	    synapses_dot.set(2,dABLPglut);
	    synapses_dot.set(3,dABLPchol);
	    synapses_dot.set(4,dLPPYglut);
	    synapses_dot.set(5,dPYLPglut);
	    synapses_dot.set(6,dLPABglut);
	    
	    
//	    System.out.println("synapses dot " + synapses_dot.toStringBis());
//	    Syn currents    					
		RealVector cell1_dot = cell1.evaluate(scell1);
		RealVector cell2_dot = cell2.evaluate(scell2);
		RealVector cell3_dot = cell3.evaluate(scell3);

//		RETURN EVOLVED STATES
		
//		RETURN V_DOT 
		RealVector v_dot = new RealVector((celldim*3)+7);
		for(int i=0; i<celldim;i++){
				v_dot.set(i,cell1_dot.get(i));
			}
		for(int i=0; i<celldim;i++){
			v_dot.set(i+celldim,cell2_dot.get(i));
		}
		
		for(int i=0; i<celldim;i++){
			v_dot.set(i+(celldim*2),cell3_dot.get(i));
		}
		for(int i=0; i<7;i++){
			v_dot.set(i+(celldim*3),1*synapses_dot.get(i));
		}		
	    return v_dot;
	}
	
	
	double iSyn(double gsyn, double sact,double Vpost,double Esyn){
	    double isyn = gsyn*sact*(Vpost - Esyn);
    return isyn;
	}

		// # Steady State Synaptic Activation
		// # 'Vth' is the synaptic threshold
		// # 'Vpre' is the presynaptic potential
		// # 'Delta' is the half activation potential
	double synSS(double Vth,double Vpre,double Delta){
	    double synSS = 1./(1. + Math.exp((Vth - Vpre)/Delta));
	    return synSS;
	}
	// # Synaptic Activation Time Constant
		// # 'k' is the rate constant for receptor-transmitter dissociation
	double tauSyn(double synSS,double k){
	    double tauSyn = (1. - synSS)/k;
	    return tauSyn;
	}

	
	public void setTemperature(double newtemp){
		this.temp = newtemp;
		cell1.setTemperature(this.temp);
		cell2.setTemperature(this.temp);
		cell3.setTemperature(this.temp);
	}
	@Override
	public int getDimension() {
		// TODO Auto-generated method stub
		return dim;
	}
	@Override
	public RealVector getParameters() {
		return p.copy();
	}
	@Override
	public void setParameters(RealVector x) {
		this.p = x.copy();
	}
	@Override
	public RealVectorField copy() {
		pyloricNetworkPrinz_q10_imi_realclean_rk4 c = new pyloricNetworkPrinz_q10_imi_realclean_rk4(); 
		c.p = p.copy();
		c.setTemperature(this.temp);
		return c;
	}	
	
	public double boltzSS(double Volt,double A,double B){
	    double act = 1./(1. + Math.exp((Volt + A)/B));
	    return act;
		}
	// Define the time constant function
	public double tauX(double Volt,double  CT,double  DT,double  AT,double  BT){
	    double timeconst = CT - DT/(1. + Math.exp((Volt + AT)/BT));
	    return timeconst;
			}
	// Some Models require a special time constant function
	public double spectau(double Volt,double  CT,double  DT,double  AT,double  BT,double  AT2,double  BT2){
	    double spec = CT + DT/(Math.exp((Volt + AT)/BT) + Math.exp((Volt + AT2)/BT2));
	    return spec;
			}

	public double iIonic(double g,double  m,double  h,double  q,double  Volt,double  Erev){
	    double flux = g*Math.pow(m, q)*h*(Volt - Erev);
	    return flux;
			}
	
	public double gE(double g,double  m,double  h,double  q,double  Volt,double  Erev){
	    double flux = g*Math.pow(m, q)*h*Erev;
	    return flux;
	}
	public double g(double g,double  m,double  h,double  q,double  Volt,double  Erev){
	    double flux = g*Math.pow(m, q)*h;
	    return flux;
	}

	
	// Define the concentration dependent Ca reversal potential
	public double CaNernst(double CaIn,double temp){
		    double R = 8.314*Math.pow(10, 3); //  # Ideal Gas Constant (*10^3 to put into mV)
		    double T = 273.15 + temp; // # Temperature in Kelvin
		    double z = 2.0;//  # Valence of Caclium Ions
		    double Far = 96485.33; //  # Faraday's Constant
		    double CaOut = 3000.0;  //# Outer Ca Concentration (uM)
		    double CalRev = ((R*T)/(z*Far))*Math.log(CaOut/CaIn);
		    // #print 'calrev ', CalRev
		    return CalRev;
	}
}
