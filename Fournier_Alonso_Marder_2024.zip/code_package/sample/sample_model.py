import sys
import os
import numpy as np
import matplotlib.pyplot as plt
import pickle


# set root_folder: this the location of the code package on your computer
# format like this: root_folder = 'C:/code_package'
root_folder = 'C:/code_package'

# choose model to test (any model from database can be run)
pathtop = root_folder + '/models/Model_A.txt'

# set total number of seconds for the simulation (10s recommended)
nsecs = 10
# length of unanalyzed transient period
nsecs_sim = 7

###################### do not edit below this line

# Add python folder to sys.path
script_directory = root_folder + '/python'
sys.path.append(script_directory)

# import scripts from python folder
from ancillary_functions import *
from integrate_and_plot_pyloric_imi_temp import *
from pyloricMeasures import *

# temperature
temp = 25

pathtoci = root_folder + '/initial_conditions_and_parameters/cis_network_imi.txt'
dump = root_folder + '/sample/sample_simulation.txt'

initial_cond_path = root_folder + '/initial_conditions_and_parameters/'

pathtojava = root_folder + '/java/model.jar'
excommand = 'java -cp '+pathtojava+' tempComp.integratePyloricNetwork_temp_imi_realclean_rk4 ' + pathtoci + ' ' + pathtop
command = excommand +' ' + str(nsecs)+' '+str(temp) + ' 0.1 '+' > ' + dump + ' '

# print command
os.system(command)
sol = np.genfromtxt(dump)

# remove transient
sol = truncate_solution(sol, nsecs, nsecs_sim)

# import classifier
with open(root_folder + '/python/classifier.pkl', "rb") as f:
    rfc = pickle.load(f)

# acquire features
features = feature_finder(sol)
features = np.array(features)
features_for_classifier = features.reshape(1, -1)

# classify trace
result = rfc.predict(features_for_classifier)
print('Pyloric') if result == [2] else print('Not Pyloric')

# plot with features
secs = nsecs - nsecs_sim
featplot(sol, secs, features)
plt.show()